# Usage Runbook

## One-time
1) Repo Settings → Actions → General → Workflow permissions → Read and write.
2) Repo Settings → Secrets and variables → Actions:
   - OPENAI_API_KEY
   - (optional) OPENAI_MODEL e.g. gpt-4.1-mini
3) Ensure workflow is present on main: .github/workflows/plugin-ci.yml
4) Ensure branch ci-input exists (the GPT will create/sync it automatically).

## Typical run (via GPT)
1) User uploads plugin ZIP to GPT.
2) GPT force-syncs ci-input to main head.
3) GPT uploads ZIP via Git Data API to ci-input at uploads/plugin.zip.
4) GPT dispatches plugin-ci.yml on ref=ci-input.
5) GPT polls run, downloads artifacts gate-reports and final-plugin.
6) GPT returns final-plugin.zip + summary.

## Manual run
Actions → workflow → Run workflow
- plugin_zip_path: uploads/plugin.zip
- max_iterations: 3 (0 to disable)
- wp_version: latest
- debug_variants: true
