# Troubleshooting

## 422 content is not valid Base64
Cause: using Contents API for multi-MB ZIP. Fix: use Git Data API (blob/tree/commit/ref).

## 422 workflow does not have workflow_dispatch trigger
Cause 1: workflow file lacks workflow_dispatch.
Cause 2: dispatching on a branch that doesn't contain the workflow file.
Fix: ensure workflow has on: workflow_dispatch and force-sync ci-input to main before dispatch.

## 403 Resource not accessible by personal access token
Token lacks permissions or repo access.
Fix: Fine-grained PAT with access to mbdslearning/wp-plugin-ci-factory:
- Contents: read/write
- Actions: read/write
- Metadata: read

## Artifacts download issues (302 redirect)
Some clients need to follow redirect. If blocked, download artifacts manually from Actions UI.

## Autofix loop doesn't run
- max_iterations set to 0 OR OPENAI_API_KEY missing.
