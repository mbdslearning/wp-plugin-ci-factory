# GPT Knowledge Base

Files:
- Custom_GPT_Instructions.txt: paste into GPT Instructions
- GPT_Action_OpenAPI_schema.yaml: paste into GPT Action schema
- Usage.md: operational runbook
- Troubleshooting.md: common errors and fixes
