<?php
declare(strict_types=1);

namespace Psr\Log;

use InvalidArgumentException as PhpInvalidArgumentException;

class InvalidArgumentException extends PhpInvalidArgumentException
{
}
