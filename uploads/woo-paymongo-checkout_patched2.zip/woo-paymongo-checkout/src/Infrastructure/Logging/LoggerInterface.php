<?php
declare(strict_types=1);

namespace Vendor\PaymongoCheckout\Infrastructure\Logging;

use Psr\Log\LoggerInterface as PsrLoggerInterface;

interface LoggerInterface extends PsrLoggerInterface
{
}
