<?php
/**
 * PHPStan bootstrap stubs for WordPress/WooCommerce symbols.
 *
 * This file is only used for static analysis and is not loaded by the plugin at runtime.
 *
 * @phpstan-ignore-file
 */

if (!function_exists('__')) { function __($text, $domain = null) { return $text; } }
if (!function_exists('esc_html__')) { function esc_html__($text, $domain = null) { return $text; } }
if (!function_exists('esc_html_e')) { function esc_html_e($text, $domain = null) { echo $text; } }

if (!function_exists('add_action')) { function add_action($tag, $function_to_add, $priority = 10, $accepted_args = 1) {} }
if (!function_exists('add_filter')) { function add_filter($tag, $function_to_add, $priority = 10, $accepted_args = 1) {} }
if (!function_exists('do_action')) { function do_action($tag, ...$arg) {} }
if (!function_exists('apply_filters')) { function apply_filters($tag, $value, ...$args) { return $value; } }

if (!function_exists('get_option')) { function get_option($option, $default = false) { return $default; } }
if (!function_exists('add_option')) { function add_option($option, $value = '', $deprecated = '', $autoload = 'yes') { return true; } }
if (!function_exists('update_option')) { function update_option($option, $value, $autoload = null) { return true; } }
if (!function_exists('delete_option')) { function delete_option($option) { return true; } }

if (!function_exists('current_user_can')) { function current_user_can($capability, ...$args) { return false; } }
if (!function_exists('is_admin')) { function is_admin() { return false; } }
if (!function_exists('wp_doing_ajax')) { function wp_doing_ajax() { return false; } }

if (!function_exists('plugin_dir_path')) { function plugin_dir_path($file) { return ''; } }
if (!function_exists('plugin_dir_url')) { function plugin_dir_url($file) { return ''; } }
if (!function_exists('plugin_basename')) { function plugin_basename($file) { return ''; } }
if (!function_exists('load_plugin_textdomain')) { function load_plugin_textdomain($domain, $deprecated = false, $plugin_rel_path = false) { return true; } }

if (!function_exists('admin_url')) { function admin_url($path = '', $scheme = 'admin') { return $path; } }
if (!function_exists('home_url')) { function home_url($path = '', $scheme = null) { return $path; } }
if (!function_exists('rest_url')) { function rest_url($path = '', $scheme = 'rest') { return $path; } }
if (!function_exists('add_query_arg')) { function add_query_arg($key, $value = null, $url = null) { return (string)($url ?? ''); } }
if (!function_exists('wp_parse_url')) { function wp_parse_url($url, $component = -1) { return []; } }

if (!function_exists('sanitize_text_field')) { function sanitize_text_field($str) { return is_string($str) ? $str : ''; } }
if (!function_exists('wp_unslash')) { function wp_unslash($value) { return $value; } }
if (!function_exists('wp_strip_all_tags')) { function wp_strip_all_tags($str, $remove_breaks = false) { return is_string($str) ? $str : ''; } }
if (!function_exists('absint')) { function absint($maybeint) { return (int) max(0, (int) $maybeint); } }

if (!function_exists('esc_html')) { function esc_html($text) { return $text; } }
if (!function_exists('esc_attr')) { function esc_attr($text) { return $text; } }
if (!function_exists('esc_url')) { function esc_url($url) { return $url; } }

if (!function_exists('wp_json_encode')) { function wp_json_encode($data, $options = 0, $depth = 512) { return json_encode($data, $options, $depth); } }

if (!function_exists('wp_safe_redirect')) { function wp_safe_redirect($location, $status = 302) { return true; } }

if (!function_exists('wp_salt')) { function wp_salt($scheme = 'auth') { return 'salt'; } }
if (!function_exists('is_wp_error')) { function is_wp_error($thing) { return $thing instanceof WP_Error; } }
if (!function_exists('get_bloginfo')) { function get_bloginfo($show = '', $filter = 'raw') { return ''; } }

if (!function_exists('wp_register_script')) { function wp_register_script($handle, $src, $deps = [], $ver = false, $in_footer = false) { return true; } }
if (!function_exists('wp_enqueue_script')) { function wp_enqueue_script($handle, $src = '', $deps = [], $ver = false, $in_footer = false) { return true; } }
if (!function_exists('wp_localize_script')) { function wp_localize_script($handle, $object_name, $l10n) { return true; } }

if (!function_exists('register_rest_route')) { function register_rest_route($namespace, $route, $args = [], $override = false) { return true; } }
if (!function_exists('register_activation_hook')) { function register_activation_hook($file, $callback) {} }
if (!function_exists('register_deactivation_hook')) { function register_deactivation_hook($file, $callback) {} }

if (!function_exists('wp_remote_request')) { function wp_remote_request($url, $args = []) { return ['body' => '', 'response' => ['code' => 200]]; } }
if (!function_exists('wp_remote_retrieve_body')) { function wp_remote_retrieve_body($response) { return is_array($response) ? (string)($response['body'] ?? '') : ''; } }
if (!function_exists('wp_remote_retrieve_response_code')) { function wp_remote_retrieve_response_code($response) { return is_array($response) ? (int)($response['response']['code'] ?? 0) : 0; } }

if (!function_exists('wc_get_order')) { function wc_get_order($order_id) { return null; } }
if (!function_exists('wc_get_orders')) { function wc_get_orders($args = []) { return []; } }
if (!function_exists('wc_get_order_statuses')) { function wc_get_order_statuses() { return []; } }
if (!function_exists('wc_add_notice')) { function wc_add_notice($message, $notice_type = 'success') {} }
if (!function_exists('wc_get_checkout_url')) { function wc_get_checkout_url() { return ''; } }
if (!function_exists('wc_clean')) { function wc_clean($var) { return $var; } }

if (!class_exists('WP_Error')) {
    class WP_Error {
        private $message = '';
        public function __construct($code = '', $message = '', $data = null) { $this->message = (string)$message; }
        public function get_error_message($code = '') { return $this->message; }
    }
}
if (!class_exists('WP_REST_Request')) {
    class WP_REST_Request {
        public function get_body() { return ''; }
        public function get_header($name) { return ''; }
    }
}
if (!class_exists('WP_REST_Response')) {
    class WP_REST_Response {
        public function __construct($data = null, $status = 200, $headers = []) {}
    }
}

if (!class_exists('WC_Order')) { class WC_Order {} }
if (!class_exists('WC_Order_Item_Product')) { class WC_Order_Item_Product {} }

if (!function_exists('WC')) {
    function WC() {
        return (object) ['cart' => (object) ['add_to_cart' => function($product_id, $quantity = 1) {} ]];
    }
}
